// نگهدارنده صف موزیک برای هر سرور
module.exports = new Map();