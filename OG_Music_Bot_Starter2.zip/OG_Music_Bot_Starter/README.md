# og-music-bot
A Persian music Discord bot with autoplay and remix support.
